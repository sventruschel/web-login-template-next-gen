import { default as dateTimeExpression_1_0 } from './functions/date-time-expression/1.0';
import { default as expression_1_0 } from './functions/expression/1.0';
import { default as generateString_1_0 } from './functions/generate-string/1.0';
import { default as sendEmail_1_0 } from './functions/send-email/1.0';
import { default as test_1_0 } from './functions/test/1.0';

const fn = {
  "dateTimeExpression 1.0": dateTimeExpression_1_0,
  "expression 1.0": expression_1_0,
  "generateString 1.0": generateString_1_0,
  "sendEmail 1.0": sendEmail_1_0,
  "test 1.0": test_1_0,
};

export default fn;
